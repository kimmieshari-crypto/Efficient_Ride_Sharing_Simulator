# Assignment 4.2 Video Walkthrough Script

## Opening

Hello, this is my Assignment 4.2 final-project preparation milestone. In this
update, I implemented Dijkstra's shortest-path algorithm with a min-heap
priority queue and integrated it into my Car class.

## Show `pathfinding.py`

My standalone function is named `find_shortest_path`, and it accepts a graph,
a start node, and an end node.

I imported Python's `heapq` module and created a priority queue containing
tuples in the form distance and node. Because `heapq` is a min-heap, the node
with the smallest current travel distance is always removed first.

The `distances` dictionary stores the best known distance from the starting
node to every discovered node. The `predecessors` dictionary stores the node
that came immediately before each node on the best route.

Inside the loop, I remove the closest node from the heap. For every neighboring
node, I calculate a possible new distance. If that distance is smaller than the
previously stored distance, I update the distance, record the predecessor, and
push the improved entry onto the heap.

After the destination is reached, I reconstruct the route by following the
predecessor dictionary backward from the destination to the starting node. I
then reverse that list so the route is returned in travel order.

If there is no route, the function returns `None` and infinity.

## Show `car.py`

Next, I added the `calculate_route` method to the Car class.

The starting node is the car's current `self.location`, and the destination is
passed into the method. The method runs the same Dijkstra logic and saves the
results in two car attributes: `self.route` and `self.route_time`.

This allows each Car object to remember the route that it has planned.

## Show `test_car_route.py`

In the test script, I first create a Graph object and load the road information
from `map.csv`.

I then create `CAR-01` at location A and call:

```python
car.calculate_route("D", city_map)
```

Finally, I print the route and route time.

## Run the Test

The output shows that the optimal route is A to C to B to D, with a total
travel time of 4.0.

This demonstrates that the Car object is successfully using the map and
Dijkstra's algorithm to calculate and store its optimal route.

## Closing

The heap-based implementation has a time complexity of approximately
`O((V + E) log V)` and supports efficient route planning for the ride-sharing
simulation.
