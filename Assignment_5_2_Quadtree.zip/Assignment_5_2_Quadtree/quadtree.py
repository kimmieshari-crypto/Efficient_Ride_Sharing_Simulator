"""Quadtree data structure for efficient nearest-neighbor searching."""

import math


class Point:
    """Represents a location on the two-dimensional map."""

    def __init__(self, x, y, data=None):
        self.x = x
        self.y = y
        self.data = data

    def __repr__(self):
        return f"Point({self.x:.2f}, {self.y:.2f})"


class Rectangle:
    """Represents the rectangular boundary of a Quadtree node."""

    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    def contains(self, point):
        """Return True when a point is inside the rectangle."""
        return (
            self.x <= point.x < self.x + self.width
            and self.y <= point.y < self.y + self.height
        )

    def distance_squared_to_point(self, point):
        """Calculate squared shortest distance from a point to this rectangle."""
        dx = max(self.x - point.x, 0, point.x - (self.x + self.width))
        dy = max(self.y - point.y, 0, point.y - (self.y + self.height))
        return dx * dx + dy * dy


class QuadtreeNode:
    """Represents one rectangular region within the Quadtree."""

    def __init__(self, boundary, capacity=4, depth=0, max_depth=20):
        self.boundary = boundary
        self.capacity = capacity
        self.depth = depth
        self.max_depth = max_depth
        self.points = []
        self.divided = False
        self.northwest = None
        self.northeast = None
        self.southwest = None
        self.southeast = None

    def subdivide(self):
        """Divide the current node into four child nodes."""
        x = self.boundary.x
        y = self.boundary.y
        half_width = self.boundary.width / 2
        half_height = self.boundary.height / 2
        next_depth = self.depth + 1

        self.northwest = QuadtreeNode(
            Rectangle(x, y, half_width, half_height),
            self.capacity, next_depth, self.max_depth
        )
        self.northeast = QuadtreeNode(
            Rectangle(x + half_width, y, half_width, half_height),
            self.capacity, next_depth, self.max_depth
        )
        self.southwest = QuadtreeNode(
            Rectangle(x, y + half_height, half_width, half_height),
            self.capacity, next_depth, self.max_depth
        )
        self.southeast = QuadtreeNode(
            Rectangle(x + half_width, y + half_height, half_width, half_height),
            self.capacity, next_depth, self.max_depth
        )
        self.divided = True

    def _insert_into_child(self, point):
        """Insert a point into the correct child node."""
        for child in (
            self.northwest,
            self.northeast,
            self.southwest,
            self.southeast,
        ):
            if child.insert(point):
                return True
        return False

    def insert(self, point):
        """Recursively insert a point into the Quadtree."""
        if not self.boundary.contains(point):
            return False

        if (
            len(self.points) < self.capacity
            or self.depth >= self.max_depth
        ) and not self.divided:
            self.points.append(point)
            return True

        if not self.divided:
            self.subdivide()
            existing_points = self.points
            self.points = []

            for existing_point in existing_points:
                if not self._insert_into_child(existing_point):
                    self.points.append(existing_point)

        return self._insert_into_child(point)

    def find_nearest_recursive(self, query_point, best_result):
        """Recursively search for the point nearest to query_point."""
        boundary_distance_squared = (
            self.boundary.distance_squared_to_point(query_point)
        )

        if boundary_distance_squared > best_result["distance_squared"]:
            return

        for point in self.points:
            distance_squared = (
                (point.x - query_point.x) ** 2
                + (point.y - query_point.y) ** 2
            )
            if distance_squared < best_result["distance_squared"]:
                best_result["point"] = point
                best_result["distance_squared"] = distance_squared

        if not self.divided:
            return

        children = [
            self.northwest,
            self.northeast,
            self.southwest,
            self.southeast,
        ]
        children.sort(
            key=lambda child: child.boundary.distance_squared_to_point(
                query_point
            )
        )

        for child in children:
            child.find_nearest_recursive(query_point, best_result)


class Quadtree:
    """Main Quadtree interface used by the ride-sharing simulator."""

    def __init__(self, boundary, capacity=4):
        self.boundary = boundary
        self.root = QuadtreeNode(boundary, capacity)

    def insert(self, point):
        """Insert a point into the Quadtree."""
        return self.root.insert(point)

    def find_nearest(self, query_point):
        """Return the nearest point and its distance."""
        best_result = {
            "point": None,
            "distance_squared": float("inf"),
        }

        self.root.find_nearest_recursive(query_point, best_result)

        if best_result["point"] is None:
            return None, float("inf")

        return (
            best_result["point"],
            math.sqrt(best_result["distance_squared"]),
        )
