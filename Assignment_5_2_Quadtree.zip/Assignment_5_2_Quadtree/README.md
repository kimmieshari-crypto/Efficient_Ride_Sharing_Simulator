# Efficient Ride-Sharing Simulator

## Assignment 5.2: Quadtree Class

This milestone implements a standalone Quadtree data structure for efficient two-dimensional spatial searching.

## Purpose

The Quadtree stores driver locations and supports efficient nearest-neighbor searches. A brute-force method checks every available driver and requires O(N) time. The Quadtree partitions the map into rectangular quadrants and can achieve approximately O(log N) average search time for well-distributed spatial data.

## Main Classes

- `Point`: Represents a driver or rider location.
- `Rectangle`: Represents a node boundary.
- `QuadtreeNode`: Stores points and recursively subdivides.
- `Quadtree`: Provides `insert()` and `find_nearest()`.

## Nearest-Neighbor Search

The search examines the closest child quadrants first. It prunes a branch when the minimum possible distance from the query point to that node's boundary is greater than the best distance already found.

## Files

- `quadtree.py`
- `test_quadtree.py`
- `README.md`
- `video_script.txt`
- `sample_output.txt`

## Run the Test

```bash
python3 test_quadtree.py
```

A successful execution prints `TEST PASSED!`.
