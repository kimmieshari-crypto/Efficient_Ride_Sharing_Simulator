"""Standalone correctness and performance test for the Quadtree."""

import math
import random
import time

from quadtree import Point, Quadtree, Rectangle


def find_nearest_brute_force(query_point, points):
    """Find the nearest point by examining every point."""
    nearest_point = None
    minimum_distance_squared = float("inf")

    for point in points:
        distance_squared = (
            (point.x - query_point.x) ** 2
            + (point.y - query_point.y) ** 2
        )

        if distance_squared < minimum_distance_squared:
            minimum_distance_squared = distance_squared
            nearest_point = point

    return nearest_point, math.sqrt(minimum_distance_squared)


def main():
    """Create, populate, and test the Quadtree."""
    random.seed(42)

    map_boundary = Rectangle(0, 0, 1000, 1000)
    quadtree = Quadtree(map_boundary, capacity=4)
    number_of_points = 5000

    points = [
        Point(
            random.uniform(0, 1000),
            random.uniform(0, 1000),
            f"Driver-{index}",
        )
        for index in range(number_of_points)
    ]

    print(f"Inserting {number_of_points} points into the Quadtree...")

    for point in points:
        if not quadtree.insert(point):
            raise ValueError(f"Point could not be inserted: {point}")

    query_point = Point(
        random.uniform(0, 1000),
        random.uniform(0, 1000),
        "Rider",
    )

    print(f"\nQuery point: {query_point}")
    print(f"Searching among {number_of_points} driver locations...\n")

    qt_start = time.perf_counter()
    qt_point, qt_distance = quadtree.find_nearest(query_point)
    qt_end = time.perf_counter()
    qt_time_ms = (qt_end - qt_start) * 1000

    bf_start = time.perf_counter()
    bf_point, bf_distance = find_nearest_brute_force(query_point, points)
    bf_end = time.perf_counter()
    bf_time_ms = (bf_end - bf_start) * 1000

    print("--- Quadtree Result ---")
    print(f"Nearest point: {qt_point}")
    print(f"Driver data: {qt_point.data}")
    print(f"Distance: {qt_distance:.6f}")
    print(f"Time: {qt_time_ms:.6f} ms\n")

    print("--- Brute-Force Result ---")
    print(f"Nearest point: {bf_point}")
    print(f"Driver data: {bf_point.data}")
    print(f"Distance: {bf_distance:.6f}")
    print(f"Time: {bf_time_ms:.6f} ms\n")

    assert qt_point is bf_point
    assert math.isclose(qt_distance, bf_distance, rel_tol=1e-9)

    print("TEST PASSED!")
    print("The Quadtree and brute-force searches found the same nearest point.")

    if qt_time_ms > 0:
        print(
            f"The Quadtree was approximately "
            f"{bf_time_ms / qt_time_ms:.2f}x faster."
        )


if __name__ == "__main__":
    main()
